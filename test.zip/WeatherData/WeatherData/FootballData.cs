﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace WeatherData
{
    internal class FootballData
    {
        public string Team { get; private set; }
        public int ScoreDiffere { get; private set; }

        private FootballData(string team, int score)
        {
            Team = team;
            ScoreDiffere = score;
          
        }
        

    }
}
