﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace WeatherData
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string rawData = File.ReadAllText(@".\weather.dat");

            var temperatureData = TemperatureData.ExtractFromRawData(rawData);
            Console.WriteLine($"Read {temperatureData.Count()} lines of weather data.");

            Func<TemperatureData, int> temperatureSpread = data => data.MaxTemp - data.MinTemp;
            var smallestSpread = temperatureData.OrderBy(temperatureSpread).First();
            Console.WriteLine("Day with the smallest temperature spread:");
            Console.WriteLine($"{smallestSpread.Day} (with a temperature spread of {temperatureSpread(smallestSpread)}°F)");

            Thread.Sleep(1800);

            string rawData1 = File.ReadAllText(@".\football.dat");

            string looser;
            int result;
            GetTheWorseTeam(rawData1, out looser, out result);
            Console.WriteLine("{0} is the looser with the result {1}", looser, result);
            Thread.Sleep(18000);



        }
        public static void GetTheWorseTeam(string fname, out string looser, out int result)
        {
            int diff = 10000;
            looser = null;
            Regex rex = new Regex(@"(?<Team>\w+)\s+(?<F>\d+)\s+(?<A>\d+)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            using (StreamReader sr = new StreamReader(@".\football.dat"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line.Trim());
                    Match m = rex.Match(line);
                    if (m.Success)
                    {
                        int f = int.Parse(m.Groups["F"].Value);
                        int a = int.Parse(m.Groups["A"].Value);
                        if (f - a < diff)
                        {
                            diff = f - a;
                            looser = m.Groups["Team"].Value;
                        }
                    }
                }
            }
            result = diff;
        }
    }
    
    
}
